package com.atoz.shop;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;

public class MainActivity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setPadding(28, 28, 28, 28);
        layout.setBackgroundColor(Color.rgb(12, 22, 42));

        TextView title = new TextView(this);
        title.setText("ATOZ SHOP");
        title.setTextSize(32);
        title.setTextColor(Color.WHITE);
        title.setGravity(Gravity.CENTER);

        TextView info = new TextView(this);
        info.setText("Welcome to ATOZ SHOP");
        info.setTextSize(18);
        info.setTextColor(Color.LTGRAY);
        info.setGravity(Gravity.CENTER);
        info.setPadding(0, 20, 0, 30);

        Button telegram = new Button(this);
        telegram.setText("OPEN TELEGRAM");
        telegram.setOnClickListener(v -> {
            Intent intent = new Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://t.me/atozofc")
            );
            startActivity(intent);
        });

        layout.addView(title);
        layout.addView(info);
        layout.addView(telegram);
        setContentView(layout);
    }
}
